package com.Store.Product_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
