export class ProductSystem {
        id!: number;
        name!: string;
        quantity!: string;
        price!: string;
        status!: string;
       
        
}
