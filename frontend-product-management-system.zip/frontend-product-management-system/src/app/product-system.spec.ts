import { ProductSystem } from "./ProductSystem";

describe('ProductSystem', () => {
  it('should create an instance', () => {
    expect(new ProductSystem()).toBeTruthy();
  });
});
